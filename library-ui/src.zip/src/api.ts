import axios from "axios";

const API_URL = "http://localhost:7143/api";

const api = axios.create({
  baseURL: API_URL,
  headers: { "Content-Type": "application/json" },
});

export const login = async (email: string, password: string) => {
  const response = await api.post("/auth/authenticate", { email, password });
  return response.data;
};

export const register = async (email: string, password: string) => {
  const response = await api.post("/auth/register", { email, password });
  return response.data;
};
