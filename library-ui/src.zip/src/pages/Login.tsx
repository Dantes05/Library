import React, { useState } from "react";
import { login } from "../api";
import { useNavigate } from "react-router-dom";

const Login: React.FC = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(""); 
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      const data = await login(email, password);
      
      if (!data.accessToken) {
        throw new Error("Токен не получен");
      }

      localStorage.setItem("token", data.accessToken);
      navigate("/books");
    } catch (error: any) {
      console.error("Ошибка авторизации:", error);
      setError("Ошибка авторизации, проверьте логин и пароль.");
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen">
      <h2 className="text-2xl font-bold mb-4">Вход</h2>
      {error && <p className="text-red-500">{error}</p>}
      <input className="border p-2 mb-2" type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input className="border p-2 mb-2" type="password" placeholder="Пароль" value={password} onChange={(e) => setPassword(e.target.value)} />
      <button className="bg-blue-500 text-white px-4 py-2" onClick={handleLogin}>Войти</button>
    </div>
  );
};

export default Login;
